##
## Welcome to Getting Started in R
##

# Use this file to do the examples and exercises.

# Running R commands: highlight the text want to run and then either click "Run"
# above or type "CTRL + ENTER" (Mac "CMD + ENTER"). The results will appear in
# the "Console" tab below. Try it now with the example below:

2*3

# Type from here onwards and regularly save your work.

